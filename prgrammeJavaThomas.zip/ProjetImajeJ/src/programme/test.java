package programme;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String desString = "bon etat";
		Image a = new Image(desString);
		
		System.out.println(a.getDateImage()+ " / " + a.getHeure());
	}

}
